from django.shortcuts import render, redirect, HttpResponse
from . import models


# =========================================================
# HOME
# =========================================================

def index(request):
    return render(request, 'index.html')


# =========================================================
# JOB PROVIDER / RECRUITER REGISTRATION
# =========================================================

def job_provider_register(request):

    if request.method == 'POST':

        company_name = request.POST.get('company_name')
        contact_person = request.POST.get('contact_person')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        company_logo = request.FILES.get('company_logo')

        # Check email already exists
        if models.JobProvider.objects.filter(email=email).exists():

            return HttpResponse(
                "<script>"
                "alert('Email already exists');"
                "window.location.href='/jpregister/';"
                "</script>"
            )

        provider = models.JobProvider(
            company_name=company_name,
            contact_person=contact_person,
            email=email,
            password=password,
            phone=phone,
            address=address,
            company_logo=company_logo
        )

        provider.save()

        return HttpResponse(
            "<script>"
            "alert('Registration successful');"
            "window.location.href='/jplogin/';"
            "</script>"
        )

    return render(request, 'jpregister.html')


# =========================================================
# JOB PROVIDER LOGIN
# =========================================================

def jplogin(request):

    if request.method == 'POST':

        email = request.POST.get('email')
        password = request.POST.get('password')

        try:

            user = models.JobProvider.objects.get(email=email)

            if user.password == password:

                request.session['email'] = user.email

                return HttpResponse(
                    "<script>"
                    "alert('Login successful');"
                    "window.location.href='/jphome/';"
                    "</script>"
                )

            else:

                return HttpResponse(
                    "<script>"
                    "alert('Incorrect password');"
                    "window.location.href='/jplogin/';"
                    "</script>"
                )

        except models.JobProvider.DoesNotExist:

            return HttpResponse(
                "<script>"
                "alert('User not found');"
                "window.location.href='/jplogin/';"
                "</script>"
            )

    return render(request, 'jplogin.html')


# =========================================================
# JOB PROVIDER HOME
# =========================================================

def jphome(request):

    if 'email' not in request.session:
        return redirect('jplogin')

    return render(request, 'jphome.html')


# =========================================================
# JOB PROVIDER PROFILE
# =========================================================

def profile(request):

    if 'email' not in request.session:
        return redirect('jplogin')

    user_email = request.session.get('email')

    try:

        user = models.JobProvider.objects.get(
            email=user_email
        )

        return render(
            request,
            'recprofile.html',
            {'u': user}
        )

    except models.JobProvider.DoesNotExist:

        return redirect('jplogin')


# =========================================================
# EDIT JOB PROVIDER PROFILE
# =========================================================

def edit_profile(request):

    if 'email' not in request.session:
        return redirect('jplogin')

    user_email = request.session.get('email')

    try:

        user = models.JobProvider.objects.get(
            email=user_email
        )

    except models.JobProvider.DoesNotExist:

        return redirect('jplogin')

    if request.method == 'POST':

        user.company_name = request.POST.get('company_name')
        user.contact_person = request.POST.get('contact_person')
        user.phone = request.POST.get('phone')
        user.address = request.POST.get('address')

        # Update password only if entered
        new_password = request.POST.get('password')

        if new_password:
            user.password = new_password

        # Update company logo only if selected
        if request.FILES.get('company_logo'):

            user.company_logo = request.FILES.get(
                'company_logo'
            )

        user.save()

        return HttpResponse(
            "<script>"
            "alert('Profile updated successfully');"
            "window.location.href='/recprofile/';"
            "</script>"
        )

    return render(
        request,
        'editprofile.html',
        {'u': user}
    )


# =========================================================
# POST JOB
# =========================================================

def postjob(request):

    if 'email' not in request.session:
        return redirect('jplogin')

    try:

        provider = models.JobProvider.objects.get(
            email=request.session['email']
        )

    except models.JobProvider.DoesNotExist:

        return redirect('jplogin')

    if request.method == 'POST':

        job = models.Job(
            job_provider=provider,
            job_title=request.POST.get('job_title'),
            description=request.POST.get('description'),
            location=request.POST.get('location'),
            job_type=request.POST.get('job_type'),
            salary=request.POST.get('salary'),
            skills=request.POST.get('skills'),

            # New jobs need admin approval
            status='Pending'
        )

        job.save()

        return HttpResponse(
            "<script>"
            "alert('Job posted successfully. Waiting for admin approval.');"
            "window.location.href='/listjobs/';"
            "</script>"
        )

    return render(request, 'postjob.html')


# =========================================================
# RECRUITER - LIST MY JOBS
# =========================================================

def list_jobs(request):

    if 'email' not in request.session:
        return redirect('jplogin')

    try:

        provider = models.JobProvider.objects.get(
            email=request.session['email']
        )

    except models.JobProvider.DoesNotExist:

        return redirect('jplogin')

    jobs = models.Job.objects.filter(
        job_provider=provider
    ).order_by('-created_at')

    return render(
        request,
        'listjobs.html',
        {'jobs': jobs}
    )

# RECRUITER - UPDATE JOB STATUS
def update_job_status(request, id):

    if 'email' not in request.session:
        return redirect('jplogin')

    try:
        provider = models.JobProvider.objects.get(
            email=request.session['email']
        )

        job = models.Job.objects.get(
            id=id,
            job_provider=provider
        )

    except (
        models.JobProvider.DoesNotExist,
        models.Job.DoesNotExist
    ):
        return HttpResponse(
            "<script>"
            "alert('Job not found or you do not have permission.');"
            "window.location.href='/listjobs/';"
            "</script>"
        )

    if request.method == 'POST':

        new_status = request.POST.get('status')

        if new_status in ['Pending', 'Active', 'Closed']:

            job.status = new_status
            job.save()

            return HttpResponse(
                "<script>"
                "alert('Job status updated successfully');"
                "window.location.href='/listjobs/';"
                "</script>"
            )

    return redirect('list_jobs')



# =========================================================
# EDIT JOB
# =========================================================

def editjob(request, id):

    if 'email' not in request.session:
        return redirect('jplogin')

    try:

        provider = models.JobProvider.objects.get(
            email=request.session['email']
        )

        # IMPORTANT:
        # Recruiter can edit only their own job
        job = models.Job.objects.get(
            id=id,
            job_provider=provider
        )

    except (
        models.JobProvider.DoesNotExist,
        models.Job.DoesNotExist
    ):

        return HttpResponse(
            "<script>"
            "alert('Job not found or you do not have permission to edit it.');"
            "window.location.href='/listjobs/';"
            "</script>"
        )

    if request.method == 'POST':

        job.job_title = request.POST.get('job_title')
        job.description = request.POST.get('description')
        job.location = request.POST.get('location')
        job.job_type = request.POST.get('job_type')
        job.salary = request.POST.get('salary')
        job.skills = request.POST.get('skills')

        # If recruiter edits the job,
        # send it back for admin approval
        job.status = 'Pending'

        job.save()

        return HttpResponse(
            "<script>"
            "alert('Job updated successfully. Waiting for admin approval.');"
            "window.location.href='/listjobs/';"
            "</script>"
        )

    return render(
        request,
        'editjob.html',
        {'job': job}
    )


# =========================================================
# DELETE JOB
# =========================================================

def deletejob(request, id):

    if 'email' not in request.session:
        return redirect('jplogin')

    try:

        provider = models.JobProvider.objects.get(
            email=request.session['email']
        )

        # Recruiter can delete only their own job
        job = models.Job.objects.get(
            id=id,
            job_provider=provider
        )

    except (
        models.JobProvider.DoesNotExist,
        models.Job.DoesNotExist
    ):

        return HttpResponse(
            "<script>"
            "alert('Job not found or you do not have permission to delete it.');"
            "window.location.href='/listjobs/';"
            "</script>"
        )

    job.delete()

    return HttpResponse(
        "<script>"
        "alert('Job deleted successfully');"
        "window.location.href='/listjobs/';"
        "</script>"
    )


# =========================================================
# USER / JOB SEEKER REGISTRATION
# =========================================================

def user_register(request):

    if request.method == 'POST':

        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phone = request.POST.get('phone')
        address = request.POST.get('address')

        profile_photo = request.FILES.get(
            'profile_photo'
        )

        resume = request.FILES.get(
            'resume'
        )

        skills = request.POST.get('skills')
        qualification = request.POST.get('qualification')

        # Check email
        if models.User.objects.filter(
            email=email
        ).exists():

            return HttpResponse(
                "<script>"
                "alert('Email already exists');"
                "window.location.href='/user_register/';"
                "</script>"
            )

        # Create user
        user = models.User(
            name=name,
            email=email,
            password=password,
            phone=phone,
            address=address,
            profile_photo=profile_photo,
            resume=resume,
            skills=skills,
            qualification=qualification,

            # New users need admin approval
            status='Pending'
        )

        user.save()

        return HttpResponse(
            "<script>"
            "alert('Registration successful. Please wait for admin approval.');"
            "window.location.href='/userlogin/';"
            "</script>"
        )

    return render(
        request,
        'user_register.html'
    )


# =========================================================
# USER LOGIN
# =========================================================

def user_login(request):

    if request.method == 'POST':

        email = request.POST.get('email')
        password = request.POST.get('password')

        try:

            user = models.User.objects.get(
                email=email
            )

            # Check password
            if user.password != password:

                return HttpResponse(
                    "<script>"
                    "alert('Incorrect password');"
                    "window.location.href='/userlogin/';"
                    "</script>"
                )

            # Check admin approval
            if user.status == 'Pending':

                return HttpResponse(
                    "<script>"
                    "alert('Your account is waiting for admin approval.');"
                    "window.location.href='/userlogin/';"
                    "</script>"
                )

            if user.status == 'Rejected':

                return HttpResponse(
                    "<script>"
                    "alert('Your registration has been rejected by the admin.');"
                    "window.location.href='/userlogin/';"
                    "</script>"
                )

            # Approved user
            request.session['user_email'] = user.email

            return HttpResponse(
                "<script>"
                "alert('Login successful');"
                "window.location.href='/userhome/';"
                "</script>"
            )

        except models.User.DoesNotExist:

            return HttpResponse(
                "<script>"
                "alert('User not found');"
                "window.location.href='/userlogin/';"
                "</script>"
            )

    return render(
        request,
        'userlogin.html'
    )


# =========================================================
# USER HOME
# =========================================================


# USER HOME

def userhome(request):

    if 'user_email' not in request.session:
        return redirect('user_login')

    email = request.session.get('user_email')

    try:

        user = models.User.objects.get(
            email=email
        )

    except models.User.DoesNotExist:

        return redirect('user_login')


    notifications = models.Notification.objects.filter(
        user=user
    ).order_by('-created_at')[:10]


    unread_count = models.Notification.objects.filter(
        user=user,
        is_read=False
    ).count()


    return render(
        request,
        'userhome.html',
        {
            'user': user,
            'notifications': notifications,
            'unread_count': unread_count
        }
    )


# =========================================================
# USER - VIEW ACTIVE JOBS
# =========================================================

def userjob_list(request):

    if 'user_email' not in request.session:
        return redirect('user_login')

    # Only ADMIN APPROVED / ACTIVE jobs
    jobs = models.Job.objects.filter(
        status='Active'
    ).select_related(
        'job_provider'
    ).order_by('-created_at')

    return render(
        request,
        'userjob_list.html',
        {'jobs': jobs}
    )


# =========================================================
# APPLY FOR JOB
# =========================================================

def apply_job(request, id):

    if 'user_email' not in request.session:
        return redirect('user_login')

    user_email = request.session.get(
        'user_email'
    )

    try:

        user = models.User.objects.get(
            email=user_email
        )

    except models.User.DoesNotExist:

        return redirect('user_login')

    try:

        # User can apply only to active jobs
        job = models.Job.objects.get(
            id=id,
            status='Active'
        )

    except models.Job.DoesNotExist:

        return HttpResponse(
            "<script>"
            "alert('This job is not available.');"
            "window.location.href='/userjob_list/';"
            "</script>"
        )

    # Check duplicate application
    if models.JobApplication.objects.filter(
        user=user,
        job=job
    ).exists():

        return HttpResponse(
            "<script>"
            "alert('You have already applied for this job');"
            "window.location.href='/userjob_list/';"
            "</script>"
        )

    if request.method == 'POST':

        cover_letter = request.POST.get(
            'cover_letter'
        )

        resume = request.FILES.get(
            'resume'
        )

        # If no new resume is uploaded,
        # use profile resume
        if not resume:
            resume = user.resume

        application = models.JobApplication(
            user=user,
            job=job,
            cover_letter=cover_letter,
            resume=resume,
            status='Applied'
        )

        application.save()

        return HttpResponse(
            "<script>"
            "alert('Application submitted successfully');"
            "window.location.href='/my_applications/';"
            "</script>"
        )

    return render(
        request,
        'apply_job.html',
        {
            'job': job,
            'user': user
        }
    )


# =========================================================
# USER - MY APPLICATIONS
# =========================================================

def my_applications(request):

    if 'user_email' not in request.session:
        return redirect('user_login')

    email = request.session.get(
        'user_email'
    )

    try:

        user = models.User.objects.get(
            email=email
        )

    except models.User.DoesNotExist:

        return redirect('user_login')

    applications = models.JobApplication.objects.filter(
        user=user
    ).select_related(
        'job',
        'job__job_provider'
    ).order_by('-applied_at')

    return render(
        request,
        'my_applications.html',
        {
            'applications': applications,
            'user': user
        }
    )


# =========================================================
# USER PROFILE
# =========================================================

def user_profile(request):

    if 'user_email' not in request.session:
        return redirect('user_login')

    user_email = request.session.get(
        'user_email'
    )

    try:

        user = models.User.objects.get(
            email=user_email
        )

        return render(
            request,
            'user_profile.html',
            {'user': user}
        )

    except models.User.DoesNotExist:

        return HttpResponse(
            "User not found"
        )


# =========================================================
# EDIT USER PROFILE
# =========================================================

def user_edit_profile(request):

    if 'user_email' not in request.session:
        return redirect('user_login')

    email = request.session.get(
        'user_email'
    )

    try:

        user = models.User.objects.get(
            email=email
        )

    except models.User.DoesNotExist:

        return redirect('user_login')

    if request.method == 'POST':

        user.name = request.POST.get(
            'name'
        )

        user.phone = request.POST.get(
            'phone'
        )

        user.address = request.POST.get(
            'address'
        )

        user.skills = request.POST.get(
            'skills'
        )

        user.qualification = request.POST.get(
            'qualification'
        )

        # Update password only if entered
        if request.POST.get('password'):

            user.password = request.POST.get(
                'password'
            )

        # Update profile photo
        if request.FILES.get('profile_photo'):

            user.profile_photo = request.FILES.get(
                'profile_photo'
            )

        # Update resume
        if request.FILES.get('resume'):

            user.resume = request.FILES.get(
                'resume'
            )

        user.save()

        return HttpResponse(
            "<script>"
            "alert('Profile updated successfully');"
            "window.location.href='/user_profile/';"
            "</script>"
        )

    return render(
        request,
        'user_edit_profile.html',
        {'user': user}
    )


# =========================================================
# ADMIN LOGIN
# =========================================================

def admin_login(request):

    if request.method == 'POST':

        email = request.POST.get(
            'email'
        )

        password = request.POST.get(
            'password'
        )

        # Simple admin credentials
        if (
            email == 'admin@gmail.com'
            and password == 'admin123'
        ):

            request.session['admin_email'] = email

            return HttpResponse(
                "<script>"
                "alert('Admin login successful');"
                "window.location.href='/admin_dashboard/';"
                "</script>"
            )

        else:

            return HttpResponse(
                "<script>"
                "alert('Invalid admin email or password');"
                "window.location.href='/admin_login/';"
                "</script>"
            )

    return render(
        request,
        'admin_login.html'
    )


# =========================================================
# ADMIN DASHBOARD
# =========================================================

def admin_dashboard(request):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    # Statistics
    total_users = models.User.objects.count()

    total_job_providers = (
        models.JobProvider.objects.count()
    )

    total_jobs = models.Job.objects.count()

    total_applications = (
        models.JobApplication.objects.count()
    )

    # Pending users
    pending_users = models.User.objects.filter(
        status='Pending'
    ).count()

    # Pending jobs
    pending_jobs = models.Job.objects.filter(
        status='Pending'
    ).count()

    # Recent applications
    recent_applications = (
        models.JobApplication.objects
        .select_related(
            'user',
            'job',
            'job__job_provider'
        )
        .order_by('-applied_at')[:10]
    )

    # Recent jobs
    recent_jobs = (
        models.Job.objects
        .select_related(
            'job_provider'
        )
        .order_by('-created_at')[:5]
    )

    context = {

        'total_users': total_users,

        'total_job_providers':
            total_job_providers,

        'total_jobs':
            total_jobs,

        'total_applications':
            total_applications,

        'pending_users':
            pending_users,

        'pending_jobs':
            pending_jobs,

        'recent_applications':
            recent_applications,

        'recent_jobs':
            recent_jobs,
    }

    return render(
        request,
        'admin_dashboard.html',
        context
    )


# =========================================================
# ADMIN LOGOUT
# =========================================================

def admin_logout(request):

    request.session.pop(
        'admin_email',
        None
    )

    return HttpResponse(
        "<script>"
        "alert('Admin logged out successfully');"
        "window.location.href='/admin_login/';"
        "</script>"
    )


# =========================================================
# ADMIN - VIEW USERS
# =========================================================

def admin_users(request):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    users = models.User.objects.all().order_by(
        '-created_at'
    )

    return render(
        request,
        'admin_users.html',
        {
            'users': users
        }
    )


# =========================================================
# ADMIN - APPROVE USER
# =========================================================

def approve_user(request, id):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    try:

        user = models.User.objects.get(
            id=id
        )

        user.status = 'Approved'
        user.save()

        return HttpResponse(
            "<script>"
            "alert('User approved successfully');"
            "window.location.href='/admin_users/';"
            "</script>"
        )

    except models.User.DoesNotExist:

        return HttpResponse(
            "<script>"
            "alert('User not found');"
            "window.location.href='/admin_users/';"
            "</script>"
        )


# =========================================================
# ADMIN - REJECT USER
# =========================================================

def reject_user(request, id):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    try:

        user = models.User.objects.get(
            id=id
        )

        user.status = 'Rejected'
        user.save()

        return HttpResponse(
            "<script>"
            "alert('User rejected');"
            "window.location.href='/admin_users/';"
            "</script>"
        )

    except models.User.DoesNotExist:

        return HttpResponse(
            "<script>"
            "alert('User not found');"
            "window.location.href='/admin_users/';"
            "</script>"
        )


# =========================================================
# ADMIN - VIEW JOB PROVIDERS
# =========================================================

def admin_job_providers(request):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    providers = models.JobProvider.objects.all().order_by(
        '-id'
    )

    return render(
        request,
        'admin_job_providers.html',
        {
            'providers': providers
        }
    )

# =========================================================
# ADMIN - VIEW ALL JOBS
# =========================================================

def admin_jobs(request):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    jobs = models.Job.objects.select_related(
        'job_provider'
    ).order_by('-created_at')

    return render(
        request,
        'admin_jobs.html',
        {
            'jobs': jobs
        }
    )


# =========================================================
# ADMIN - CHANGE JOB STATUS
# =========================================================

def change_job_status(request, id):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    try:

        job = models.Job.objects.get(
            id=id
        )

    except models.Job.DoesNotExist:

        return HttpResponse(
            "<script>"
            "alert('Job not found');"
            "window.location.href='/admin_jobs/';"
            "</script>"
        )

    if request.method == 'POST':

        new_status = request.POST.get(
            'status'
        )

        # Allowed statuses
        if new_status in [
            'Pending',
            'Active',
            'Closed'
        ]:

            job.status = new_status
            job.save()

        return redirect(
            'admin_jobs'
        )

    return redirect(
        'admin_jobs'
    )


# =========================================================
# ADMIN - VIEW APPLICATIONS
# =========================================================

def admin_applications(request):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    applications = (
        models.JobApplication.objects
        .select_related(
            'user',
            'job',
            'job__job_provider'
        )
        .order_by('-applied_at')
    )

    return render(
        request,
        'admin_applications.html',
        {
            'applications': applications
        }
    )

def approve_job_provider(request, id):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    try:

        provider = models.JobProvider.objects.get(
            id=id
        )

        provider.status = 'Approved'
        provider.save()

        return HttpResponse(
            "<script>"
            "alert('Job provider approved successfully');"
            "window.location.href='/admin_job_providers/';"
            "</script>"
        )

    except models.JobProvider.DoesNotExist:

        return HttpResponse(
            "<script>"
            "alert('Job provider not found');"
            "window.location.href='/admin_job_providers/';"
            "</script>"
        )
def reject_job_provider(request, id):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    try:

        provider = models.JobProvider.objects.get(
            id=id
        )

        provider.status = 'Rejected'
        provider.save()

        return HttpResponse(
            "<script>"
            "alert('Job provider rejected');"
            "window.location.href='/admin_job_providers/';"
            "</script>"
        )

    except models.JobProvider.DoesNotExist:

        return HttpResponse(
            "<script>"
            "alert('Job provider not found');"
            "window.location.href='/admin_job_providers/';"
            "</script>"
        )

def update_application_status(request, id):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    try:
        application = models.JobApplication.objects.get(id=id)

        if request.method == 'POST':

            new_status = request.POST.get('status')

            if new_status in [
                'Applied',
                'Under Review',
                'Shortlisted',
                'Interview',
                'Selected',
                'Rejected'
            ]:

                application.status = new_status
                application.save()

            return redirect('admin_applications')

    except models.JobApplication.DoesNotExist:

        return HttpResponse(
            "<script>"
            "alert('Application not found');"
            "window.location.href='/admin_applications/';"
            "</script>"
        )

    return redirect('admin_applications')


# ADMIN - CREATE NOTIFICATION

def admin_notification(request):

    if 'admin_email' not in request.session:
        return redirect('admin_login')

    users = models.User.objects.filter(
        status='Approved'
    ).order_by('name')

    if request.method == 'POST':

        user_id = request.POST.get('user')
        title = request.POST.get('title')
        message = request.POST.get('message')

        # Send notification to all users
        if user_id == 'all':

            for user in users:

                models.Notification.objects.create(
                    user=user,
                    title=title,
                    message=message
                )

        # Send notification to selected user
        else:

            try:

                user = models.User.objects.get(
                    id=user_id
                )

                models.Notification.objects.create(
                    user=user,
                    title=title,
                    message=message
                )

            except models.User.DoesNotExist:

                return HttpResponse(
                    "<script>"
                    "alert('User not found');"
                    "window.location.href='/admin_notification/';"
                    "</script>"
                )

        return HttpResponse(
            "<script>"
            "alert('Notification sent successfully');"
            "window.location.href='/admin_notification/';"
            "</script>"
        )

    return render(
        request,
        'admin_notification.html',
        {'users': users}
    )

