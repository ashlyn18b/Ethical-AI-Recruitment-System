from django.urls import path
from . import views

urlpatterns = [

    path('', views.index, name='index'),

    path('jpregister/', views.job_provider_register, name='jpregister'),
    path('jplogin/', views.jplogin, name='jplogin'),
    path('jphome/', views.jphome, name='jphome'),
    path('recprofile/', views.profile, name='recprofile'),
    path('editprofile/', views.edit_profile, name='editprofile'),
    path('postjob/', views.postjob, name='postjob'),
    path('listjobs/', views.list_jobs, name='listjobs'),
    path('editjob/<int:id>/', views.editjob, name='editjob'),
    path('deletejob/<int:id>/', views.deletejob, name='deletejob'),
path(
    'update_job_status/<int:id>/',
    views.update_job_status,
    name='update_job_status'
),


    path('user_register/', views.user_register, name='user_register'),
    path('userlogin/', views.user_login, name='user_login'),
    path('userhome/', views.userhome, name='userhome'),
    path('userjob_list/', views.userjob_list, name='userjob_list'),
    path('apply_job/<int:id>/', views.apply_job, name='apply_job'),
    path('my_applications/', views.my_applications, name='my_applications'),
    path('user_profile/', views.user_profile, name='user_profile'),
    path('user_edit_profile/', views.user_edit_profile, name='user_edit_profile'),

    path('admin_login/', views.admin_login, name='admin_login'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin_logout/', views.admin_logout, name='admin_logout'),

    path('admin_users/', views.admin_users, name='admin_users'),
    path('approve_user/<int:id>/', views.approve_user, name='approve_user'),
    path('reject_user/<int:id>/', views.reject_user, name='reject_user'),

    path('admin_jobs/', views.admin_jobs, name='admin_jobs'),
    path('change_job_status/<int:id>/', views.change_job_status, name='change_job_status'),

    path('admin_job_providers/', views.admin_job_providers, name='admin_job_providers'),

    path('admin_applications/', views.admin_applications, name='admin_applications'),
    path('approve_job_provider/<int:id>/', views.approve_job_provider, name='approve_job_provider'),

    path('reject_job_provider/<int:id>/', views.reject_job_provider, name='reject_job_provider'),
    path('update_application_status/<int:id>/', views.update_application_status, name='update_application_status'),
    
    path('admin_notification/',views.admin_notification,name='admin_notification'),


]