from django.db import models


class JobProvider(models.Model):

    PROVIDER_STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    ]

    company_name = models.CharField(max_length=200,null=True,blank=True)

    contact_person = models.CharField(
        max_length=100,
        null=True,
        blank=True
    )

    email = models.EmailField(
        unique=True
    )

    password = models.CharField(
        max_length=200,
        null=True,
        blank=True
    )

    phone = models.CharField(
        max_length=15,
        null=True,
        blank=True
    )

    address = models.TextField(max_length=100,null=True,blank=True)

    company_logo = models.ImageField(upload_to='company_logos/',blank=True,null=True)

    status = models.CharField(max_length=20,choices=PROVIDER_STATUS_CHOICES,default='Pending')

    def __str__(self):
        return self.company_name

class Job(models.Model):

    JOB_STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Active', 'Active'),
        ('Closed', 'Closed'),
    ]

    job_provider = models.ForeignKey(
        JobProvider,
        on_delete=models.CASCADE
    )

    job_title = models.CharField(max_length=200)

    description = models.TextField()

    location = models.CharField(max_length=100)

    job_type = models.CharField(max_length=50)

    salary = models.CharField(max_length=100)

    skills = models.TextField()

    status = models.CharField(
        max_length=20,
        choices=JOB_STATUS_CHOICES,
        default='Pending'
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.job_title


class User(models.Model):

    USER_STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    ]

    name = models.CharField(max_length=100)

    email = models.EmailField(unique=True)

    password = models.CharField(max_length=100)

    phone = models.CharField(max_length=20)

    address = models.TextField()

    profile_photo = models.ImageField(
        upload_to='user_profiles/',
        blank=True,
        null=True
    )

    resume = models.FileField(
        upload_to='resumes/',
        blank=True,
        null=True
    )

    skills = models.TextField(
        blank=True,
        null=True
    )

    qualification = models.CharField(
        max_length=200,
        blank=True,
        null=True
    )

    status = models.CharField(
        max_length=20,
        choices=USER_STATUS_CHOICES,
        default='Pending'
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):
        return self.name


class JobApplication(models.Model):

    STATUS_CHOICES = [
        ('Applied', 'Applied'),
        ('Under Review', 'Under Review'),
        ('Shortlisted', 'Shortlisted'),
        ('Interview', 'Interview'),
        ('Selected', 'Selected'),
        ('Rejected', 'Rejected'),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE
    )

    job = models.ForeignKey(
        Job,
        on_delete=models.CASCADE
    )

    cover_letter = models.TextField()

    resume = models.FileField(
        upload_to='application_resumes/',
        blank=True,
        null=True
    )

    status = models.CharField(
        max_length=50,
        choices=STATUS_CHOICES,
        default='Applied'
    )

    applied_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):
        return self.user.name + " - " + self.job.job_title

class Notification(models.Model):

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    title = models.CharField(max_length=200)

    message = models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)

    is_read = models.BooleanField(default=False)

    def __str__(self):
        if self.user:
            return self.user.name + " - " + self.title
        return "All Users - " + self.title

